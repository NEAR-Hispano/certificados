const express = require('express');
const app = express(),
      bodyParser = require("body-parser");
      port = 3070;

//const cors = require('cors');

const fs = require('fs')
const path = require('path')
const multer  = require('multer')
//const upload = require('./libs/storage');

/*
app.use(cors({
  origin: '*'
}));
*/

// app.use(bodyParser.json());
// app.use(express.static(process.cwd() + '/my-app/dist'));

//inicio configuracion AirTable //
const API_KEY = "keyU8cfqozWZJCz8p";
const BASE_NAME = "appS801YP8fm8r5u9";
const TABLE_NAME = "Table 1"
const Airtable = require('airtable')
Airtable.configure({apiKey: API_KEY});
const base = Airtable.base(BASE_NAME);
const table = base(TABLE_NAME);
//fin configuracion AirTable //


// inicio configuracion smart contract near //
const { CONFIG } = require('./network/api')
const nearAPI = require("near-api-js");
const { Contract, keyStores, KeyPair , Near, Account } = nearAPI;

/* const homedir = require("os").homedir();
const CREDENTIALS_DIR = "AppData\\Local\Packages\\CanonicalGroupLimited.Ubuntu20.04onWindows_79rhkp1fndgsc\\LocalState\\rootfs\\root\\.near-credentials";
const credentialsPath = require("path").join(homedir, CREDENTIALS_DIR);
const keyStore = new keyStores.UnencryptedFileSystemKeyStore(credentialsPath); */
const keyStore = new keyStores.InMemoryKeyStore();
//Connect to network
const config = CONFIG(keyStore, 'testnet');
const CONTRACT_NAME = 'nft.nearcertificate.testnet';
const SIGNER_ID = 'nft.nearcertificate.testnet';
const SIGNER_PRIVATEKEY = 'ed25519:3PQrUAb7JqrTwZNvjZTu2C4sT7nrNr3HWvdfrMS76J6E7su6uUBQ7TVjSMamQ2UKt2cpDepSuCdqJkWqYFdPPgJR';
const NETWORK = 'testnet';
const keyPair = KeyPair.fromString(SIGNER_PRIVATEKEY);

keyStore.setKey(NETWORK, SIGNER_ID, keyPair);
const near = new Near(config);
const account = new Account(near.connection, SIGNER_ID);
const response = null;

//Contract call buy or sell
const contract = new Contract(account, CONTRACT_NAME, {
    viewMethods: ["get_certificate_list"],
    changeMethods: ["set_certificate_list"],
    sender: account
})
// fin configuracion smart contract near //

// libreria para la creacion de imagenes //
const nodeHtmlToImage = require('node-html-to-image')

// inicio configuracion Web3 Storage //
//const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaWQ6ZXRocjoweEQyMzU0QTViZkU4RTREQkNFYjZmYjYzNThlNDAzM0NiMzUxOTNlNGEiLCJpc3MiOiJ3ZWIzLXN0b3JhZ2UiLCJpYXQiOjE2NTIxOTY1Njc4NTYsIm5hbWUiOiJmcmVlX2hvcnNlcyJ9.OA8aoNBwLQA0WV8drtL3reEgDk2e8nJEYGO9UC3YdzM";
//const storage = new Web3Storage({ token });
// fin configuracion Web3 Storage //



let contador = 0;
async function crearImagen(nombre, certificado, user_id){
  console.log("entro a crear imagen", nombre, certificado, user_id)
  const imagefirma = fs.readFileSync('./firma.png');
  console.log("debug 1 ");
  const base64Imagefirma = new Buffer.from(imagefirma).toString('base64');
  console.log("debug 2 ");
  const dataURIfirma = 'data:image/png;base64,' + base64Imagefirma
  console.log("debug 3 ");
  const imageNear = fs.readFileSync('./near.png');
  console.log("debug 4 ");
  const base64ImageNear = new Buffer.from(imageNear).toString('base64');
  console.log("debug 5 ");
  const dataURINear = 'data:image/png;base64,' + base64ImageNear
  console.log("debug 6 ");
  const image = await nodeHtmlToImage({
    html: `
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Near Certified - Certification</title>
</head>

<body>
    <section>
        <div>
            <img class="logo" src="{{imageNear}}" alt="Near Protocol">
        </div>

        <div>
            <h2>Certificado de Finalización</h2>
            <span>La Cofradía de NEAR Hispano Certifica a:</span>
            <h3>Leyner D. Aponte Herrera</h3>
            <p>
                Por haber Cumplido satisfactoriamente en el periodo del 17 de Enero 
                al 21 de Enero del 2022 con los requerimientos del programa 
                <strong>NEAR Certified Analyst</strong> (NCA entrenamiento enfocado a entusiastas 
                en la tecnología Blockchain de NEAR
            </p>
            <img class="firma" src="{{imageSource}}" alt="Firma">
        </div>
    </section>
</body>
</html>

<style>
* {
    box-sizing: border-box;
}
:is(html, body) {
    margin: 0;
    padding: 0;
    background-color: #f2f2f2;
    font-family: sans-serif;
}
body {
    display: flex;
    align-items: center;
    justify-content: center;
    height: max(100vh, 640px);
    position: relative;
}
body:after {
    content: "";
    position: absolute;
    width: 100%;
    height: 100%;
    background-color: #000000;
    clip-path: polygon(60% 0, 85% 0, 97% 100%, 65% 100%, 0 65%, 0 35%);
    /* transform: scale(1.5); */
}


/* card */
section {
    --padding: 5%;
    background-color: #FFFFFF;
    z-index: 2;
    display: flex;
    flex-direction: column;
    justify-content: center;
    /* max-width: calc(50em + var(--padding)); */
    max-width: min(90%, calc(90ch + var(--padding)));
    padding-inline: var(--padding);
    padding-block: 2em 2.5em;
    box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
}
div:first-child {
    display: flex;
    justify-content: flex-end;
    position: relative;
    padding-bottom: 1em;
}
div:first-child::after {
    content: "";
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    margin-inline: auto;
    width: 100%;
    height: 2px;
    background-color: #e9e9e9;
    border-radius: 30px;
}
div+div {
    --margin: 15px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    margin-inline: auto;
}
.logo {
    width: 9.375em;
    aspect-ratio: 2 / 1;
}
h2 {
    font-size: 2.2em;
    font-weight: bold;
    margin-bottom: var(--margin);
}
:is(span, p) {
    font-size: 1.2em;
    color: #9999a6;
}
span {
    margin-bottom: var(--margin);
}
p {
    margin-bottom: 0;
}
h3 {
    font-size: 2em;
    font-weight: normal;
    color: #6f6f7f;
    margin-block: 0 var(--margin);
}
strong {
    color: #57576b;
}
.firma {
    width: 18.75em;
    aspect-ratio: 2 / 1;
}
@media (max-width: 700px) {
    .logo {
        width: clamp(7em, 9vw, 9.375em);
    }
    h2 {
        font-size: clamp(1.8em, 2.2vw, 2.2em);
    }
    :is(span, p) {
        font-size: clamp(.8em, 1.2vw, 1.2em);
    }
    h3 {
        font-size: clamp(1.6em, 2vw, 2em);
    }
    .firma {
        width: clamp(12em, 18vw, 18.75em);
    }
}
</style>

  `,
  content: { imageSource: dataURIfirma, imageNear: dataURINear }
  });
  console.log("debug 7 ");
  res.writeHead(200, { 'Content-Type': 'image/png' });
  console.log("debug 8 ");
  res.end(image, 'binary');
  console.log("debug 9 ");
  return true
}

function servicio() {
  console.log("ejecuto funcion")
  // se consulta la lista de certificados en el AirTable//
  table.select({
    //view: "Grid view",
    filterByFormula: "{certificado} = 1"
  }).eachPage(async function page(records) {
    // se recorre la lista devuelta por el api de AirTable //
    records.forEach(async function(record) {
      console.log(record.fields);
      //console.log(record.fields['NEAR mainnet']);
      // se consulta la lista de certificados en el smart contract por cada user id //
      this.response = await contract.get_certificate_list( {
        account_id: record.fields['NEAR mainnet'],
      }).then((res) => {
        // cada resultado por usuario se compara para evitar cargarle mas de una vez el mismo certificado //
        let verificacion = res.find(element => element.certificacion == record.fields['certificacion (from bootcamp)']);
        if (verificacion == undefined) {
          console.log("entro al if y se creo el certificado")

        } 
      })
      .catch((err) => {
        // en caso de error es por que el usuario no tiene certificados, se procede a agregar el usuario //
        console.log("se creo el nuevo usuario");
        
      });
    })
  });
}

app.listen(port, () => {
  console.log(`Server listening on the port::${port}`);
  servicio();
  crearImagen("hector palencia", "NCA", "hrpalencia.testnet")
  /*
  setInterval(function () {
    contador = contador + 1;
    console.log(`Server is running ${contador}`);
    console.log(API_KEY)
    prub();
  }.bind(this), 5000);*/
});

/*
try {
      this.response = await contract.get_order_sell( {
        order_id: parseInt(arg[2]),
        status: 1
      });
    } catch (err) {
      console.log(err);
    }*/